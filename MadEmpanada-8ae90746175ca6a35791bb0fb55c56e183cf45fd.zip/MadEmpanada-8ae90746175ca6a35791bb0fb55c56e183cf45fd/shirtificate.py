from fpdf import FPDF
from PIL import Image

class PDF(FPDF):
    def header(self):
        # Rendering logo:
        self.image("shirtificate.png", w = 180, h = 190, x=15, y=60)
        # Setting font: helvetica bold 15
        self.set_font("helvetica", "", 45)
        # Moving cursor to the right:
        self.cell(80)
        self.set_xy(90, 30)
        # Printing title:
        self.cell(30, 10, "CS50 Shirtificate", border=0, align="C")
        # Performing a line break:
        self.ln(20)

#Getting user's name
users_name = input("Name: ")

# Instantiation of inherited class
pdf = PDF(orientation="P", unit="mm", format="A4")
pdf.add_page()
pdf.set_xy(90, 125)
pdf.set_font("helvetica", "", 25)
pdf.set_text_color(255, 255, 255)
pdf.cell(30, 10, f"{users_name} took CS50", border=0, align="C")
pdf.output("shirtificate.pdf")
